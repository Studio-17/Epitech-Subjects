/*
** EPITECH PROJECT, 2021
** Paradigms Seminar
** File description:
** Day 07 AM
*/

#pragma once

enum Destination
{
    EARTH,
    VULCAN,
    ROMULUS,
    REMUS,
    UNICOMPLEX,
    JUPITER,
    BABEL
};
