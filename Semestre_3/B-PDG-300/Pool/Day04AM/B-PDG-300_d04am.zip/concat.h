/*
** EPITECH PROJECT, 2021
** Paradigms Seminar
** File description:
** Exercise 02
*/

#pragma once

typedef struct concat_s
{
    const char  *str1;
    const char  *str2;
    char        *res;
}   concat_t;
