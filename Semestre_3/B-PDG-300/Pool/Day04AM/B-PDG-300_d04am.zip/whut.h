/*
** EPITECH PROJECT, 2021
** Paradigms Seminar
** File description:
** Exercise 08
*/

#pragma once

#pragma pack(1)
typedef struct whut_s
{
    char    s[21];
    int     member;
    char    c;
}   whut_t;
