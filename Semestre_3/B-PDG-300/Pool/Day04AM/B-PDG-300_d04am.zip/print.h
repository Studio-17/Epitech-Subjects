/*
** EPITECH PROJECT, 2021
** Paradigms Seminar
** File description:
** Exercise 04
*/

#pragma once

typedef enum action_e
{
    PRINT_NORMAL,
    PRINT_REVERSE,
    PRINT_UPPER,
    PRINT_42,

    PRINT_COUNT /* Number of actions */
}   action_t;
