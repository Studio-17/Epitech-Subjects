#pragma once

#include "BaseComponent.hpp"

class AtmosphereRegulator : public BaseComponent
{
public:
    AtmosphereRegulator();
    virtual ~AtmosphereRegulator();
};
