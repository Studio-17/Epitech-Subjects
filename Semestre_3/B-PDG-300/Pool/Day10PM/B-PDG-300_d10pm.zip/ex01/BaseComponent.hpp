#pragma once

// Base class for all rover's components.
class BaseComponent
{
public:
    virtual ~BaseComponent() = default;
};
